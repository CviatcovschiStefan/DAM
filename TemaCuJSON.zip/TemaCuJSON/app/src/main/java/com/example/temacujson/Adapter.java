package com.example.temacujson;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class Adapter extends BaseAdapter {


    private List<Products> listaProducts = new ArrayList();


    public Adapter(List<Products> listaProducts) {
        this.listaProducts = listaProducts;
    }

    @Override
    public int getCount() {
        return listaProducts.size();
    }

    @Override
    public Products getItem(int i) {
        return listaProducts.get(i);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int pos, View view, ViewGroup viewGroup) {

        LayoutInflater inflater = LayoutInflater.from(viewGroup.getContext());
        View view1 = inflater.inflate(R.layout.macheta_products, viewGroup, false);

        TextView textViewName = view1.findViewById(R.id.name);
        TextView textViewPrice = view1.findViewById(R.id.price);
        TextView textViewDescription = view1.findViewById(R.id.description);

        Products oras = listaProducts.get(pos);

        textViewName.setText(oras.getName());
        textViewPrice.setText(oras.getPrice()+"");
        textViewDescription.setText(oras.getDescription());

        return view1;
    }

    public void updateList(List<Products> listaNoua)
    {
        listaProducts.addAll(listaNoua);
        notifyDataSetChanged();
    }
}
