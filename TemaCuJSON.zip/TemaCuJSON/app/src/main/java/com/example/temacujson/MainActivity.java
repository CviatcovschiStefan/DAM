package com.example.temacujson;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ListView listView;
    private Adapter adapter;
    private JSONRead jsonRead;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        listView = findViewById(R.id.listview);
        adapter = new Adapter(lista());
        listView.setAdapter(adapter);

        jsonRead = new JSONRead();
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                jsonRead.read("https://jsonkeeper.com/b/C1K0", new IResponse() {
                    @Override
                    public void onSucces(List<Products> list) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                adapter.updateList(list);
                            }
                        });
                    }

                    @Override
                    public void onError(String errorMessage) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(MainActivity.this, errorMessage, Toast.LENGTH_LONG).show();
                            }
                        });
                    }
                });
            }
        });
        thread.start();

    }
    private List<Products> lista()
    {
        ArrayList lista = new ArrayList<Products>();

        Products produs1 = new Products("Biscuiti", 10, "cu ciocolata");
        Products produs2 = new Products("Ferrero Rocher", 20, "cele mai bune");

        lista.add(produs1);
        lista.add(produs2);

        return lista;
    }

}