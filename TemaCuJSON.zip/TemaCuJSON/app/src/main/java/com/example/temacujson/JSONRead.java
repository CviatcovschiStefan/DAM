package com.example.temacujson;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class JSONRead {

    public void read(String param_url, IResponse response)
    {
        try {
            URL url = new URL(param_url);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();

            InputStream inputStream = connection.getInputStream();
            InputStreamReader streamReader = new InputStreamReader(inputStream);
            BufferedReader bufferedReader = new BufferedReader(streamReader);

            StringBuilder result = new StringBuilder();
            String line = "";

            while((line= bufferedReader.readLine())!=null)
            {
                result.append(line);
            }

            List<Products> list = Parsare(result.toString());

            response.onSucces(list);


            Log.v("rezulat", list.toString());

            bufferedReader.close();
            streamReader.close();
            inputStream.close();


        } catch (MalformedURLException e) {
            e.printStackTrace();
            response.onError(e.getMessage());
        } catch (IOException e) {
            e.printStackTrace();
            response.onError(e.getMessage());
        }
    }

    private List<Products> Parsare(String jsonString)
    {
        List<Products> listaJson = new ArrayList<>();
        try {
            JSONObject object = new JSONObject(jsonString);
            JSONArray array = object.getJSONArray("products");
            for(int i=0;i<array.length();i++)
            {
                JSONObject jsonObject = array.getJSONObject(i);
                String name = jsonObject.getString("name");
                Integer price = jsonObject.getInt("price");
                String descriere = jsonObject.getString("description");


                Products products = new Products(name, price, descriere);
                listaJson.add(products);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return listaJson;
    }
}
