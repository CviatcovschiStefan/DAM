package com.example.temacujson;

import java.util.List;

public interface IResponse {
    public void onSucces(List<Products> list);
    public void onError(String errorMessage);
}
